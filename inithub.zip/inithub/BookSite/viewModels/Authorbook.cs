﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BookSite.Models;

namespace BookSite.viewModels
{
    public class Authorbook
    {

        public IEnumerable<Author> Authors { get; set; }
        public IEnumerable<Book> Books { get; set; }
        public IEnumerable<Genre> Genres { get; set; }


    }
}