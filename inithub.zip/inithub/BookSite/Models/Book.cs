﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace BookSite.Models
{
    public class Book
    {
        public int BookID{ get; set; }
       
        [Required]
        [StringLength(10,MinimumLength=3)]
        public string Title { get; set; }
        
        public virtual Author Author { get; set; }
        public int AuthorID { get; set; }
        public virtual Genre Genre { get; set; }
        public int GenreID { get; set; }
        public int price { get; set; }    
    }
}