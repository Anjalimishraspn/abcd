﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace BookSite.Models
{
    public class Author
    {
   
        public int AuthorID { get; set; }
       
        [StringLength(50, MinimumLength = 3)]
       [Required]
        public string name{ get; set; }
        
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString= "{0:dd-MM-yyyy}",ApplyFormatInEditMode = true)]
        public DateTime Dob { get; set; }
        
        public ICollection<Book> Books { get; set; }
    
    }
}