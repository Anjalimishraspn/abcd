﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Web;

namespace BookSite.Models
{
    public class Genre
    {
        
        public int GenreID  { get; set; }
        
        [Required]
         [StringLength(50, MinimumLength = 3)]
        public string name  { get; set; }
        
        [StringLength(50, MinimumLength = 3)]
        public string Description { get; set; }
        
        public virtual ICollection<Book> Books { get; set; }
    }
}