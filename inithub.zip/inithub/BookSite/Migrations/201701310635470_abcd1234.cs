namespace BookSite.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class abcd1234 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Book", "Author_AuthorID", "dbo.Author");
            DropForeignKey("dbo.Book", "Genre_GenreID", "dbo.Genre");
            DropIndex("dbo.Book", new[] { "Author_AuthorID" });
            DropIndex("dbo.Book", new[] { "Genre_GenreID" });
            RenameColumn(table: "dbo.Book", name: "Author_AuthorID", newName: "AuthorID");
            RenameColumn(table: "dbo.Book", name: "Genre_GenreID", newName: "GenreID");
            AlterColumn("dbo.Book", "AuthorID", c => c.Int(nullable: false));
            AlterColumn("dbo.Book", "GenreID", c => c.Int(nullable: false));
            CreateIndex("dbo.Book", "AuthorID");
            CreateIndex("dbo.Book", "GenreID");
            AddForeignKey("dbo.Book", "AuthorID", "dbo.Author", "AuthorID", cascadeDelete: true);
            AddForeignKey("dbo.Book", "GenreID", "dbo.Genre", "GenreID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Book", "GenreID", "dbo.Genre");
            DropForeignKey("dbo.Book", "AuthorID", "dbo.Author");
            DropIndex("dbo.Book", new[] { "GenreID" });
            DropIndex("dbo.Book", new[] { "AuthorID" });
            AlterColumn("dbo.Book", "GenreID", c => c.Int());
            AlterColumn("dbo.Book", "AuthorID", c => c.Int());
            RenameColumn(table: "dbo.Book", name: "GenreID", newName: "Genre_GenreID");
            RenameColumn(table: "dbo.Book", name: "AuthorID", newName: "Author_AuthorID");
            CreateIndex("dbo.Book", "Genre_GenreID");
            CreateIndex("dbo.Book", "Author_AuthorID");
            AddForeignKey("dbo.Book", "Genre_GenreID", "dbo.Genre", "GenreID");
            AddForeignKey("dbo.Book", "Author_AuthorID", "dbo.Author", "AuthorID");
        }
    }
}
