namespace BookSite.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class updatea : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Author",
                c => new
                    {
                        AuthorID = c.Int(nullable: false),
                        name = c.String(nullable: false, maxLength: 50),
                        Dob = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.AuthorID);
            
            CreateTable(
                "dbo.Book",
                c => new
                    {
                        BookID = c.Int(nullable: false, identity: true),
                        Title = c.String(nullable: false, maxLength: 10),
                        price = c.Int(nullable: false),
                        Author_AuthorID = c.Int(),
                        Genre_GenreID = c.Int(),
                    })
                .PrimaryKey(t => t.BookID)
                .ForeignKey("dbo.Author", t => t.Author_AuthorID)
                .ForeignKey("dbo.Genre", t => t.Genre_GenreID)
                .Index(t => t.Author_AuthorID)
                .Index(t => t.Genre_GenreID);
            
            CreateTable(
                "dbo.Genre",
                c => new
                    {
                        GenreID = c.Int(nullable: false),
                        name = c.String(nullable: false, maxLength: 50),
                        Description = c.String(maxLength: 50),
                    })
                .PrimaryKey(t => t.GenreID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Book", "Genre_GenreID", "dbo.Genre");
            DropForeignKey("dbo.Book", "Author_AuthorID", "dbo.Author");
            DropIndex("dbo.Book", new[] { "Genre_GenreID" });
            DropIndex("dbo.Book", new[] { "Author_AuthorID" });
            DropTable("dbo.Genre");
            DropTable("dbo.Book");
            DropTable("dbo.Author");
        }
    }
}
