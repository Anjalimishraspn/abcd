namespace BookSite.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class abcd1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Book", "Author_AuthorID", "dbo.Author");
            DropForeignKey("dbo.Book", "Genre_GenreID", "dbo.Genre");
            DropPrimaryKey("dbo.Author");
            DropPrimaryKey("dbo.Genre");
            AlterColumn("dbo.Author", "AuthorID", c => c.Int(nullable: false, identity: true));
            AlterColumn("dbo.Genre", "GenreID", c => c.Int(nullable: false, identity: true));
            AddPrimaryKey("dbo.Author", "AuthorID");
            AddPrimaryKey("dbo.Genre", "GenreID");
            AddForeignKey("dbo.Book", "Author_AuthorID", "dbo.Author", "AuthorID");
            AddForeignKey("dbo.Book", "Genre_GenreID", "dbo.Genre", "GenreID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Book", "Genre_GenreID", "dbo.Genre");
            DropForeignKey("dbo.Book", "Author_AuthorID", "dbo.Author");
            DropPrimaryKey("dbo.Genre");
            DropPrimaryKey("dbo.Author");
            AlterColumn("dbo.Genre", "GenreID", c => c.Int(nullable: false));
            AlterColumn("dbo.Author", "AuthorID", c => c.Int(nullable: false));
            AddPrimaryKey("dbo.Genre", "GenreID");
            AddPrimaryKey("dbo.Author", "AuthorID");
            AddForeignKey("dbo.Book", "Genre_GenreID", "dbo.Genre", "GenreID");
            AddForeignKey("dbo.Book", "Author_AuthorID", "dbo.Author", "AuthorID");
        }
    }
}
